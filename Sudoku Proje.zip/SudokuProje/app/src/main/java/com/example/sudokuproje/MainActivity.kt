package com.example.sudokuproje

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.sudokuproje.Oyun.Cell
import com.example.sudokuproje.SudokuZemin
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() , SudokuZemin.OnTouchListener{

    private lateinit var viewModel: PlaySudokuViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        SudokuZemin.registerListener(this)
        viewModel = ViewModelProviders.of(this).get(PlaySudokuViewModel::class.java)
        viewModel.sudokuGame.selectedLiveData.observe(this, Observer{updateSelectedCellUI(it)})
        viewModel.sudokuGame.cellsLiveData.observe(this, Observer { updateCells(it) })



        val buttons = listOf(birbutton, ikibutton, ucbutton , dortbutton , besbutton , altibutton , yedibutton , sekizbutton , dokuzbutton)


        buttons.forEachIndexed{index, button ->
            button.setOnClickListener{
                viewModel.sudokuGame.handleInput(index+1)
            }

        }
        notesButton.setOnClickListener{
            viewModel.sudokuGame.changeNoteTakingState()
        }

    }

    private  fun updateCells (cells: List<Cell>?)=cells?.let {
        SudokuZemin.updateCells(cells)

    }
    private fun updateSelectedCellUI(cell : Pair<Int,Int>? ) = cell?.let {
      SudokuZemin.updateSelectedCellUI(cell.first,cell.second)

    }
    private fun updateNoteTakingUI(isNoteTaking: Boolean?) = isNoteTaking?.let {
        if (it) {
            notesButton.setBackgroundColor(ContextCompat.getColor(this, R.color.colorPrimary))
        } else {
            notesButton.setBackgroundColor(Color.LTGRAY)
        }
    }



    override fun onCellTouched(row:Int,col:Int){
        viewModel.sudokuGame.updateSelectedCell(row,col)
    }

    }

