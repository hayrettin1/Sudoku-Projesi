package com.example.sudokuproje.Oyun

import androidx.lifecycle.MutableLiveData
import kotlinx.android.synthetic.main.activity_main.*

class SudokuGame {
        var selectedLiveData = MutableLiveData<Pair<Int,Int>>()
    var cellsLiveData = MutableLiveData<List<Cell>>()
    val isTakingNotesLiveData = MutableLiveData<Boolean>()
    val highLightedKeysLiveData = MutableLiveData<Set<Int>>()

    private  var selectedRow = -1
    private var selectedCol = -1
    private var isTakingNotes =false
    private val board: Board
    init {
        val cells = List(9*9) { i -> Cell(i/9,i%9,i%9)
        }
        cells[0].notes = mutableSetOf(1,2,3,4,5,6,7,8,9)
        board = Board(9,cells)
        selectedLiveData.postValue(Pair(selectedRow,selectedCol))
        cellsLiveData.postValue(board.cells)
        isTakingNotesLiveData.postValue(isTakingNotes)
    }
    fun handleInput(number:Int) {
        if (selectedRow == -1 || selectedCol == -1) return
        val cell = board.getCell(selectedRow, selectedCol)
        if (cell.isStartingCell) return
        if (isTakingNotes) {
            if (cell.notes.contains(number)){
              cell.notes.remove(number)

            }else {
                cell.notes.add(number)
            }
            highLightedKeysLiveData.postValue(cell.notes)

        } else {
            cell.value = number


        }
        cellsLiveData.postValue(board.cells)
        }
    fun updateSelectedCell (row :Int , col:Int){
        val cell = board.getCell(row,col)
        if(cell.isStartingCell) {


            selectedCol = col
            selectedRow = row
            selectedLiveData.postValue(Pair(row, col))
            if(isTakingNotes){
                highLightedKeysLiveData.postValue(cell.notes)
            }
        }
    }
    fun changeNoteTakingState(){
        isTakingNotes = !isTakingNotes
        isTakingNotesLiveData.postValue(isTakingNotes)
        val curNotes = if(isTakingNotes){
            board.getCell(selectedRow,selectedCol).notes
        }
        else{
            setOf<Int>()
        }
        highLightedKeysLiveData.postValue(curNotes)
    }

    }