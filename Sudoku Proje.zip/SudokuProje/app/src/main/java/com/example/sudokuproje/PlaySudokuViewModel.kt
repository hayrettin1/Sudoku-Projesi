package com.example.sudokuproje

import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import com.example.sudokuproje.Oyun.SudokuGame

class PlaySudokuViewModel : ViewModel(){
    val sudokuGame = SudokuGame()


}
